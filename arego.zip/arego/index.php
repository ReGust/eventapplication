<?php

include("$_SERVER[DOCUMENT_ROOT]/arego/config.php");
require_once 'classes/db.php';

session_start();

if (isset($_SESSION['errors'])) {
    $errors = $_SESSION['errors'];
    print_r($errors);
}
session_destroy();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="scripts.js"></script>
</head>
<body>
    <div class="container">
        <div class="card row" id="form">
            <form action="form-post.php" method="POST">
                <input type="hidden" name="action" value="registerUser">
                <div class="col-sm-3">
                    <?php if (isset($errors['name'])): ?>
                        <div>
                            <?php foreach($errors['name'] as $error): ?>
                                <h5><? echo $error ?></h5>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <label for="name">Name: (* required)</label>
                    <input name="name" class="form-control" type="text">
                </div>
                <div class="col-sm-3">
                    <?php if (isset($errors['email'])): ?>
                    <div>
                        <?php foreach($errors['email'] as $error): ?>
                        <h5><?php echo $error ?></h5>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <label for="email">Email: (* required)</label>
                    <input name="email" class="form-control" type="email">
                </div>
                <div class="col-sm-3">
                    <?php if (isset($errors['town'])): ?>
                        <div>
                            <h5><?php echo $errors['town'] ?></h5>
                        </div>
                    <?php endif; ?>
                    <label for="town">City: (* required)</label>
                    <select name="town" id="town" class="form-control">
                        <option value="null">-- Choose City --</option>
                        <option value="Tallinn">Tallinn</option>
                        <option value="Tartu">Tartu</option>
                        <option value="Narva">Narva</option>
                        <option value="Pärnu">Pärnu</option>
                        <option value="Jõhvi">Jõhvi</option>
                        <option value="Jõgeva">Jõgeva</option>
                        <option value="Põlva">Põlva</option>
                        <option value="Valga">Valga</option>
                    </select>
                </div>
                <div class="col-sm-3">
                    <?php if (isset($errors['date'])): ?>
                        <div>
                            <h5><?php echo $errors['date'] ?></h5>
                        </div>
                    <?php endif; ?>
                    <label for="date">Date: (* required)</label>
                    <select name="date" id="date" class="form-control" disabled>

                    </select>
                </div>
                <div class="col-sm-8" style="margin: 30px 30px 30px 0;">
                    <label for="comment">Comment</label>
                    <input name="comment" class="form-control" type="textarea" >
                </div>
                <div class="col-sm-8 notification" style="margin-right: 30px; margin-top: 30px; display: none;">

                </div>
                <div class="col-sm-3"  style="float: right;">
                    <div style="float: right; margin-right: 30px; margin-top: 30px;">
                        <button type="submit" class="btn btn-primary" id="register">Register</button>
                    </div>
                </div>
            </form>
        </div>

    </div>

</body>
</html>
