How the application works?

- all field have a validation check
- if user selects a city, the application makes a request to the server with the selected city (with javascript) and the server
responds with the information is the sky clear at the time or not, in order for event to take place there has to be 2 times
3 hour times span that has to has a clear sky.
- javascript checks the response does it have clear sky in both times if not then the option is not added to the select menu,
otherwise it is
- once registred the registration is saved into the database and the confirmation email is sent to user using PHP native mail() function.
