<?php
define('DBUSER','root');
define('DBPWD','');
define('DBHOST','localhost');
define('DBNAME','arego');
define('CHARSET','utf8mb4');
define('APIKEY','f63a322a0db5dbdc7af8118b77ad7797');