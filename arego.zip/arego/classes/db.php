<?php

//include("$_SERVER[DOCUMENT_ROOT]/arego/config.php");

class db
{
    private $host;
    private $db;
    private $user;
    private $pass;
    private $charset;
    private $pdo;

    public function __construct($charset = 'utf8mb4')
    {
        $this->host = DBHOST;
        $this->db = DBNAME;
        $this->user = DBUSER;
        $this->pass = DBPWD;
        $this->charset = CHARSET;
        $this->connect();
    }

    private function connect()
    {
        $dsn = "mysql:host=$this->host;dbname=$this->db;charset=$this->charset";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass, $options);
        } catch (\PDOException $e) {
            throw new \PDOException($e->getMessage(), (int)$e->getCode());
        }

    }

    public function registerPerson( $name, $email, $town, $dateandtime, $comment)
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO registrations (name, email, town, dateandtime, comment) 
            VALUES ( :name , :phone , :email)');
        $stmt->execute( array($name, $email, $town, $dateandtime, $comment));

        return $this->pdo->lastInsertId();
    }

    public function sendConfirmationEmail($name, $datetime, $town, $email)
    {
        $datetime = explode(' ', $datetime);
        $date = implode(array_reverse(explode('-', $datetime[0])));
        $msg = 'Hey '. $name .', you’ve been registered to the star observers event in '. $town .' on '. $date .' at '. $datetime[1] . ' !';
        mail($email, 'Registration Confirmation For Star Observers', $msg);
    }

}