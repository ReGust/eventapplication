<?php

include("$_SERVER[DOCUMENT_ROOT]/arego/config.php");

class weatherapi
{
    const url = 'api.openweathermap.org/data/2.5/forecast?';

    public static function getWeather($city)
    {
        $ch = curl_init();
        $googleApiUrl = self::url . 'q=' . $city . '&units=metric' . '&appid='. APIKEY;
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $googleApiUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $request = curl_exec($ch);
        return json_decode(curl_exec($ch));

    }

}