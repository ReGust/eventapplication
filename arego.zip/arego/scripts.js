
$(function() {
    $('#town').change( e => {
        let city = e.target.options[e.target.selectedIndex].value;
        if (city !== null) {
            postData(city)
        }
    })

});

function postData(city)
{
    $.ajax({
        type: "POST",
        url: 'form-post.php',
        data: {
            action: 'getWeatherInfo',
            data: JSON.stringify(city)
        },
        success: function (response) {
            let json = JSON.parse(response)
            let reset = true;
            let date = $('#date')[0];
            date.disabled = true;
            date.innerHTML = '';

            if (response.length > 0) {
                for (const key in json){
                    let item = json[key];

                    if (Object.keys(item.condition).length > 1) {
                        let date = $('#date')[0];
                        reset = false;
                        date.disabled = false;
                        date.innerHTML +=
                            `<option value="${key}">${key}</option>`;
                    }
                }
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown)
        }
    });
}
