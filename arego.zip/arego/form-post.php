<?php

require_once 'classes/db.php';
require_once 'classes/weatherapi.php';
session_start();

if (isset($_POST['action']) && $_POST['action'] == 'getWeatherInfo') {
    $city = json_decode($_POST['data']);
    $weather = weatherapi::getWeather($city);

    // both of the 3 hour cycle time need to be clear sky in order for event to take place
    $weathertocheck = array(
        '20:00:00' => array('18:00:00', '21:00:00'),
        '23:00:00' => array('21:00:00', '00:00:00'),
        '02:00:00' => array('00:00:00', '03:00:00'),
        '05:00:00' => array('03:00:00', '06:00:00'),
        );

    $times = array();

    foreach ($weather->list as $weatherperiod) {
        $skip = false;
        $time = explode(' ', $weatherperiod->dt_txt);

        foreach ($weathertocheck as $key => $item) {
            if (!in_array($time[1], $item)) {
                $skip = true;
            } else {
                $weatherCondition = $weatherperiod->weather[0]->main;
                if ($weatherCondition === 'Clear') {
                    $dateTime = $time[0] . ' ' . $key;
                    $times[$dateTime]['date'] = $time[0];
                    $times[$dateTime]['condition'][$time[1]] = 'Clear';
                }
            }
        }
    }
    die(json_encode($times));
} elseif (isset($_POST['action']) && $_POST['action'] == 'registerUser') {

    $allowedPlaces = array('Tallinn', 'Tartu', 'Narva', 'Pärnu', 'Jõhvi', 'Jõgeva', 'Põlva', 'Valga');
    $errors = array();

    if (!isset($_POST['name'])) {
        $errors['name'][] = 'Please check the name field';
    } elseif ( strlen($_POST['name']) > 50 ) {
        $errors['name'][] = 'Name must be less than 50 characters';
    } elseif (ctype_alpha(str_replace(' ', '', $_POST['name'])) === false) {
        $errors['name'][] = 'Name must contain letters and spaces only';
    }

    if (!isset($_POST['email'])) {
        $errors['email'][] = 'Please check the email field';
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'][] = 'Please check the email format';
    }
    if (!isset($_POST['town']) || !in_array($_POST['town'], $allowedPlaces) || $_POST['town'] == null) {
        $errors['town'] = 'Please select a city';
    }

    if (!isset($_POST['date']) || $_POST['date'] == null) {
        $errors['date'] = 'Please select a date';
    }

    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: index.php');
    }

    $name = $_POST['name'];
    $email = $_POST['email'];
    $town = $_POST['town'];
    $date = $_POST['date'];
    $comment = $_POST['comment'];

    $db = new DB();
    $db->registerPerson();

}
